/*
Author: Myles Murphy
Date: 11/5/2017
The program below was created to fufill the requirements for the ALU project. The program features a function named "ALU" which takes the same inputs a physical arithmetic logic unit would take, and gives the corresponding result - effectively creating a simulation using a level programming language of the physical ALU.
 */

//Our includes!
#include "blogic.H"
#include <iostream>
using namespace std; //Proper namespace

int alu(int F_0, int F_1, int INVA, int ENA, int ENB, int CIV, int A, int B) { //ALU function - a serious of gates simulated using a high level programming language 
  return (2 * bor( band( band( bxor( INVA, band( A, ENA)), band(B, ENB)), band( bnot(F_0), bnot(F_1))), band( bor( bxor( INVA, band( A, ENA)), band( B, ENB)), band( bnot(F_0), F_1)), band( bnot( band( B, ENB)), band( F_0, bnot(F_1))), band( bxor( CIV, bxor( band( B, ENB), bxor(INVA, band( A, ENA)))), band(F_0, F_1)))) + (bor( band( band( F_0, F_1), bxor( INVA, band( A, ENA)), band( B, ENB)), band( band( F_0, F_1), bxor( band( B, ENB), bxor( INVA, band( A, ENA))), CIV)));
}

void print_call(int F_0, int F_1, int INVA, int ENA, int ENB, int CIV, int A, int B) { //A function to nicely print out our ALI function, including the input
  cout << "alu(" << F_0 << ", " << F_1 << ", " << INVA << ", " << ENA << ", " << ENB << ", " << CIV << ", " << A << ", " << B << ") --> " << alu(F_0,F_1,INVA,ENA,ENB,CIV,A,B) << endl;
}

void print_section(int F_0, int F_1, int INVA, int ENA, int ENB) { //Print a section
  cout << endl;
  cout << "F0=" << F_0 << ", F1=" << F_1 << ", INVA=" << INVA << ", ENA=" << ENA << ", ENB=" << ENB << endl;
  print_call(F_0, F_1, INVA, ENA, ENB, 0, 0, 0);
  print_call(F_0, F_1, INVA, ENA, ENB, 0, 0, 1);
  print_call(F_0, F_1, INVA, ENA, ENB, 0, 1, 0);
  print_call(F_0, F_1, INVA, ENA, ENB, 0, 1, 1);
  print_call(F_0, F_1, INVA, ENA, ENB, 1, 0, 0);
  print_call(F_0, F_1, INVA, ENA, ENB, 1, 0, 1);
  print_call(F_0, F_1, INVA, ENA, ENB, 1, 1, 0);
  print_call(F_0, F_1, INVA, ENA, ENB, 1, 1, 1);
}

int main() { //Our main function, testing every possible input
  print_section(0,0,0,0,0);
  print_section(0,0,0,0,1);
  print_section(0,0,0,1,0);
  print_section(0,0,0,1,1);
  print_section(0,0,1,0,0);
  print_section(0,0,1,0,1);
  print_section(0,0,1,1,0);
  print_section(0,0,1,1,1);

  print_section(0,1,0,0,0);
  print_section(0,1,0,0,1);
  print_section(0,1,0,1,0);
  print_section(0,1,0,1,1);
  print_section(0,1,1,0,0);
  print_section(0,1,1,0,1);
  print_section(0,1,1,1,0);
  print_section(0,1,1,1,1);

  print_section(1,0,0,0,0);
  print_section(1,0,0,0,1);
  print_section(1,0,0,1,0);
  print_section(1,0,0,1,1);
  print_section(1,0,1,0,0);
  print_section(1,0,1,0,1);
  print_section(1,0,1,1,0);
  print_section(1,0,1,1,1);

  print_section(1,1,0,0,0);
  print_section(1,1,0,0,1);
  print_section(1,1,0,1,0);
  print_section(1,1,0,1,1);
  print_section(1,1,1,0,0);
  print_section(1,1,1,0,1);
  print_section(1,1,1,1,0);
  print_section(1,1,1,1,1);

  return 0;
}
