/*
AUTHOR: Myles Murphy
DATE: 3/11

The code below is to satisfy the requirements for CS 273's Shell project.
The program when run can take a main argument argv, to indicate the environment
After that, the user can enter into the command line whatever they want to execute, 
along with keywords "time" to execute system call "times()", or "exit" in order to exit the shell

 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>

#ifndef MAXTOKS //maxtoks to signify the maximum number of tokens
#define MAXTOKS 15

enum status_value { NORMAL, EOF_OR_ERROR, TOO_MANY_TOKENS }; //enum for struct status

struct name { //name struct 
  char** tok;
  int count;
  int status;
};

int read_name(struct name *n) { //function in order to read in values
  char *getlinebuff = NULL; //set up the buffer
  size_t getlinelen = 100; //length
  int numChars; //number of characters

  n->tok = malloc(MAXTOKS * sizeof(char**)); //allocate the memory

  numChars = getline(&getlinebuff, &getlinelen, stdin); //get the input

  if(numChars == -1) //set the correct status
    n->status = EOF_OR_ERROR;
  else 
    n->status = NORMAL;

  int count = 0; //count for our loop, tokCount to be able to set the struct count value when completed
  int tokCount = 0;
  while(count < numChars) { //making sure we havent run out of characters

    if(tokCount >= MAXTOKS && count < numChars) { //making sure we havent gone past the max tok count
      break;
    }

    if(isspace(getlinebuff[count]) || getlinebuff[count] == '\0') { //checking for spaces and null chars
      count++;
      continue;
    }
    else {
      int N = 0;
      while(!isspace(getlinebuff[N + count])) //not a space
	N++;

      n->tok[tokCount] = malloc((N+1) * sizeof(char));
  
      int i = 0;
      while(i < N) {
	n->tok[tokCount][i] = getlinebuff[i + count];
	i++;
      }
      n->tok[tokCount][N] = NULL;
      count += N;
      tokCount++;
    }

    n->count = tokCount;

  }

  if(n->status == NORMAL) //return the status
    return 1;
  else if (n->status == TOO_MANY_TOKENS)
    return 2;
  else
    return 0;
}

void print_toks(struct name *n) {
  int i = 0;
  while(n->tok[i] != NULL) {
    printf("<%s>\n", n->tok[i]);
    i++;
  }
  if(n->tok[i] == NULL)
    printf("Null char\n");
}

int main(int argc, char *const argv[]) {
  struct name n;
  int rnRet = read_name(&n);

  if(n.tok[0] == NULL) { //if the user enters nothing then count it as an exit
      n.tok[0] = "exit";
  }

  /*
  print_toks(&n);
  printf("Ret val: %d\n", rnRet);
  */

  while(strcmp(n.tok[0], "exit") != 0) { //looping as long is its not time to exit
    if(strcmp(n.tok[0], "time") == 0) { //check for time
      printf("%d\n", times());
      }
    else { //else exec whatever they entered using a child process
      pid_t pid;
      if ((pid = fork()) < 0) { //fork failed
	printf("fork() FAILED");
	perror("forkeg");
	_exit(1);
      }
      else if(pid==0) { //our child process
	execve(n.tok[0], n.tok, argv); //exec
	//execve(n.tok[0], argv, n.tok);
	_exit(1); //succesfull exit
      }
      else { //parent process waits on child
	pid = wait();
      }
    }

    rnRet = read_name(&n); //get the next user input

    if(n.tok[0] == NULL) { //if the input is nothing then exit
      n.tok[0] = "exit";
    }

  }

}

#endif
