== External Documentation ==

== Extra Features ==

The program when run can take a main argument argv, to indicate the environment
After that, the user can enter into the command line whatever they want to execute, 
along with keywords "time" to execute system call "times()", or "exit" in order to exit the shell, or the user enters blank space.