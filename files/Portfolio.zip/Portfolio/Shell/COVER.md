[I pledge my honor that I have neither given nor received assistance on this programming
project, except as explicitly stated on this page, and that I have seen no dishonest work.
Signed MYLES MURPHY
I    have    intentionally    not    signed    the    pledge    (check  only  if  appropriate)]

== Help received ==
I received no help on this phase of this assignment, with the exception of asking for a reminder of the order of the arguments of execve