/** Implementation file for Book class methods */
#include "Book2.h"

/** Default constructor */
Book::Book() {
  cout << "Using the default constructor is stupid, DON'T DO IT" << endl;
}


/** Input stream constructor */
Book::Book(istream &is){
  if(&is == &cin){
    rm = 0;
    is.ignore(); //clears the '/n' left in the bitstream by ">>"
    cout << "Title: ";
    getline(is, title);
    cout << "Author: ";
    getline(is, author);
    cout << "isbn: ";
    is >> isbn;
    cout << "edition: ";
    is >> edition;
    cout << "printing: ";
    is >> printing;
    cout << "date purchased: ";
    is >> date_purchase;
    cout << "codition (New, LikeNew, VeryGood, Good, Acceptable): ";
    is >> condition;
    cout << "hardcover = 1, softcover = 0: ";
    is >> hs_cover;
    cout << "location purchased: ";
    is.ignore();
    getline(is, loc_purch);
    cout << "amount paid: ";
    is >> paid_amt;
    cout << "selling price: ";
    is >> sell_price;
    yr_sold = -1;
    cout << "selling site: ";
    is >> selling_site;
  }else{
    rm = 0;
    is.ignore(); //Ignoring whitespace
    getline(is, title, '*');
    is.ignore();//Ignoring whitespace
    getline(is, author, '*');
    is >> isbn;
    is >> edition;
    is >> printing;
    is >> yr_print;
    is >> date_purchase;
    is >> condition;
    is >> hs_cover;
    is.ignore();//Ignoring whitespace
    getline(is, loc_purch, '*');
    is >> paid_amt;
    is >> sell_price;
    is >> yr_sold;
    is >> selling_site;
  }
}

/** 13-argument constructor */
Book::Book(string t, string a, string I, int e, int p, string yP, string dP, int c, bool hC, string lP, float pA, float sP, int sS){
  title = t;
  author = a;
  isbn = I;
  edition = e;
  printing = p;
  yr_print = yP;
  date_purchase = dP;
  condition = c;
  hs_cover = hC;
  loc_purch = lP;
  paid_amt = pA;
  sell_price = sP;
  yr_sold = -1;
  selling_site = sS;
}

/** Copy constructor */
Book::Book(Book &bk) {
  rm = 0;
  title = bk.title;
  author = bk.author;
  isbn = bk.isbn;
  edition = bk.edition;
  printing = bk.printing;
  yr_print = bk.yr_print;
  date_purchase = bk.date_purchase;
  condition = bk.condition;
  hs_cover = bk.hs_cover;
  loc_purch = bk.loc_purch;
  paid_amt = bk.paid_amt;
  yr_sold = bk.yr_sold;
  selling_site = bk.selling_site;
}

/** Display method - print to cout */
void Book::display() {
  // Only displays certain fields - title, author, edition, printing
  std::cout << title << ", " << author << "; ";
  std::cout << "Edition " << edition;
  std::cout << ", printing " << printing << std::endl;
}

/*void Book:: solddisplay() {
  std::cout << title << ", " << author << "; ";
  std::cout << "Edition " << edition;
  std::cout << ", printing " << printing << "; ";
  std::cout << "Year sold " << yr_sold << std:: endl;
  }*/
  
void Book::printAll(ostream &ostr){
  // Displays/outputs all state variables to ostr
  ostr << title << "* "
       << author << "* "
       << isbn << " "
       << edition <<  " "
       << printing << " "
       << yr_print << " "
       << date_purchase << " "
       << condition << " "
       << hs_cover << " "
       << loc_purch << "* "
       << paid_amt << " "
       << sell_price << " "
       << yr_sold << " "
       << selling_site << endl;
}

/** Assignment operator = */
Book& Book::operator = (Book &bk) {
  return *this;
}
