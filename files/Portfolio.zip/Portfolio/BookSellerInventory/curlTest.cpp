#include <iostream>
#include <string>
#include <curl/curl.h>
#include "rapidjson/rapidjson.h"
#include "rapidjson/document.h"

using namespace rapidjson;

template <typename T, size_t N>
inline
size_t SizeOfArray( const T(&)[ N ] ){
  return N;
}

static size_t WriteCallback(void *contents, size_t size, size_t nmemb, void *userp)
{
    ((std::string*)userp)->append((char*)contents, size * nmemb);
    return size * nmemb;
}


int main(){
  CURL *curl = curl_easy_init();
  std::string readBuffer;
  const std::string Baseurl = "https://www.googleapis.com/books/v1/volumes?q=isbn:";
  std::string isbn;
  std::cout << "Enter a isbn number: ";
  std::cin >> isbn;
  std::string myurl = Baseurl + isbn;
  const char* MyUrl = myurl.c_str();
  if(curl) {
    curl_easy_setopt(curl, CURLOPT_URL, MyUrl);
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &readBuffer);
    curl_easy_perform(curl);
    curl_easy_cleanup(curl);
  }
  std::cout << readBuffer << std::endl;
  Document dom;
  dom.Parse(readBuffer.c_str());
  if(dom["totalItems"].GetInt() == 0){
    std::cout << "No information found" << std::endl;
  }else{
    std::string title = dom["items"][0]["volumeInfo"]["title"].GetString();
    std::string author;
    std::string authors;
    std::string comma = ", ";
    for(auto &v : dom["items"][0]["volumeInfo"]["authors"].GetArray()){
      author = v.GetString();
      authors += comma + author;
    }
    authors.erase(0,2);
    std::string ISBN = dom["items"][0]["volumeInfo"]["industryIdentifiers"][0]["identifier"].GetString();
    std::string publishDate = dom["items"][0]["volumeInfo"]["publishedDate"].GetString();
    std::cout << title << std::endl;
    std::cout << authors << std::endl;
    std::cout << ISBN << std::endl;
    std::cout << publishDate << std::endl;
  }
  return 0;
}
