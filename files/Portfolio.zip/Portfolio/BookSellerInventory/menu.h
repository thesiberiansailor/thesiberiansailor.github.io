#ifndef _menu_
#define _menu_
#include <iostream>
#include <string>
#include "menuItem.h"
using namespace std;

class menu{
  menuItem* items;
  int len;
public:
  menu(int l);
  ~menu();
  int get_len () {return len;};
  void setMenuItem(int index, string title);
  void display();
};

#endif
