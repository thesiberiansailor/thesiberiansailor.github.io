#ifndef _menuItem_
#define _menuItem_
#include <iostream>
#include <string>
using namespace std;

class menuItem{
  int index;
  string text;
public:
  menuItem(int in, string txt);
  menuItem();
  void display();
};

#endif
