#include "menu.h"

menu::menu(int l){
  len = l;
  items = new menuItem[l];
}

menu::~menu(){
  delete[] items;
}

void menu::setMenuItem(int index, string title){
  items[index-1] = menuItem(index, title);
}

void menu::display(){
  for(int i = 0; i < len; i++){
    items[i].display();
  }
  // cout << "Your choice(1-" << len << "):";
}
