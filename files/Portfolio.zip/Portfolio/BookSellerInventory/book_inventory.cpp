#include <iostream>
#include <fstream>
#include <string>
#include <cstring>
#include "Inventory.h"
#include "Book2.h"
#include "menuItem.h"
#include "menu.h"
using namespace std;


/** Function to determine/call appropriate search function from Inventory class */ 
void searchBook(Inventory &invent){
  int i;
  cin >> i;
  if(cin.fail()) // Checking to see if the user actually entered an integer
  {
    cout << "Error.  Choice entered is not an integer type." << endl;
    cin.clear();
    cin.ignore();
  }


  string str1;
  string is;
  switch(i){
    case 0:  // return to the previous menu
      break;
    case 1:  // search by title
      cout << "Please enter in a title: ";
      cin.ignore();
      getline(cin,str1);
      invent.searchTit(str1);
      break;
    case 2:  // search by author
      cout << "Please enter in an author: ";
      cin.ignore();
      getline(cin,str1);
      invent.searchAut(str1);
      break;
    case 3:  // search by ISBN
      cout << "Please enter in an ISBN number: ";
      cin >> is;
      invent.searchISBN(is);
      break;
   default: // user entered an integer other than 0, 1, 2, or 3
      cout << "Enter a valid input option" << endl;
      break;
  }
}

/** Function to determine/call appropriate sort function from Inventory class */ 
void sortBook(Inventory &invent){
  int i;
  cin >> i;
  if(cin.fail())  // Checking to see if the user actually entered an integer
  {
    cout << "Error.  Choice entered is not an integer type." << endl;
    cin.clear();
    cin.ignore();
  }

  switch(i){
    case 0:  // return to the previous menu
      break;
    case 1:  // sort by title
      invent.sortTitle();
      break;
    case 2:  // sort by author
      invent.sortAuthor();
      break;
    case 3:  // sort by ISBN
      invent.sortISBN();
      break;
    default:  // user entered an integer other than 0, 1, 2, or 3
      cout << "Enter a valid input option" << endl;
      break;
  }
}


void main_Menu(Inventory &invent, Inventory &soldBooks){
  bool x = true;  // Used for while loop that displays or returns to main menu
  
  menu mainMenu(7);
  ifstream so("soldbook.txt");

  // Setting up the choices/options for the main menu
  mainMenu.setMenuItem(1, "Add a book");
  mainMenu.setMenuItem(2, "Remove a book");
  mainMenu.setMenuItem(3, "Display all unsold books");
  mainMenu.setMenuItem(4, "Search for books");
  mainMenu.setMenuItem(5, "Sort inventory");
  mainMenu.setMenuItem(6, "Display all sold books");
  mainMenu.setMenuItem(7, "Quit");

  // Setting up the choices/options for the search menu
  menu searchMenu(3);
  searchMenu.setMenuItem(1, "Title");
  searchMenu.setMenuItem(2, "Author");
  searchMenu.setMenuItem(3, "ISBN");

  // Setting up the choices/options for the sort menu
  menu sortMenu(3);
  sortMenu.setMenuItem(1, "Title");
  sortMenu.setMenuItem(2, "Author");
  sortMenu.setMenuItem(3, "ISBN");
  
  int choice;  // Placeholder int for the user's input
  while(x){
   
    cout << "Please select one of the following choices:" << endl;
    mainMenu.display();
    cout << "Your choice(1-" << mainMenu.get_len() << "):";
    cin >> choice;   // User inputs a choice for the main menu options
    if(cin.fail()){  // Checking to make sure the user actually inputs an integer
      cout << "Error.  Choice entered is not an integer type." << endl;
      cin.clear();
      cin.ignore();
    }
    int sol;  // Placeholder int for the number of sold books
    switch(choice){
    case 1:  // Add a book
      invent.addBook();
      break;
    case 2:  // Remove a book
      invent.rmInventory();
      break;
    case 3:  // Display the inventory
      invent.display();
      break;
    case 4:  // Display the search menu
      searchMenu.display();
      cout << "Your choice(1-" << searchMenu.get_len() << ", 0 to return to previous menu):";
      searchBook(invent);
      break;
    case 5: // Display the sort menu
      sortMenu.display();
      cout << "Your choice(1-" << sortMenu.get_len() << ", 0 to return to previous menu):";
      sortBook(invent);
      break;
    case 6:  // Display all of the sold books in the inventory
      sol = soldBooks.getNumBooks();
      if(sol<0) {
	cout << "No sold books. " << endl;
      }
      else {
        soldBooks.display();
        invent.soldDisplay();
	    }
      break;
    case 7:  // Quitting the main menu
      x = false;
      break;
    default:
      cout << "Enter a valid input option" << endl;
    }
  }
}


int main(){
  cout << "Welcome to Bookseller Inventory!" << endl;
  int size;
  int sol;
  ifstream so("soldbook.txt");
  if(!so){
    sol = 0;
  }else{
    so >> sol;
  }
  Inventory soldBooks(sol);
  if(sol){
    soldBooks.loadFromDB(so);
  }
  so.close();
  ifstream db("books_db.txt");
  if(!db){
    size = 0;
  }else{
    db >> size;
  }
  Inventory invent(size);
  if(size){
    invent.loadFromDB(db);
  }
  db.close();

  
  main_Menu(invent, soldBooks);
  soldBooks.copySold(invent);
  ofstream dbOut("books_db.txt");
  invent.close(dbOut);
  dbOut.close();
  ofstream soOut("soldbook.txt");
  soldBooks.close(soOut);
  soOut.close();

  cout << "Goodbye!" << endl;
  return 0;
}
