#ifndef _item_
#define _item_
#include <iostream>
#include <string>

class item{
protected:
  string title;
  string date_purchase;
  string condition; //can be enum instead of string
  string loc_purch;
  float amt_paid;
  float sell_price;
  int year_sold;
  string date_sold;
  string selling_site;
public:
};

#endif
