//OUR INCLUSIONS
#include <iostream>
#include <fstream>
#include <string.h>
#include <cstring>
#include <math.h>
#include <stdlib.h>
#include <sstream>
#include "texture.h"
#include "Inventory.h"
#include "Book2.h"
#include "menuItem.h"
#include "menu.h"

//testing if it's the Mac OS
#ifdef MACOSX
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif

//defining our namespace
using namespace std;

//Using LibCurl and JSon to retrieve ISBN information
#include <curl/curl.h>
#include "rapidjson/rapidjson.h"
#include "rapidjson/document.h"

//Including the rapidjson namespace
using namespace rapidjson;

//Initializing our inventory
Inventory invent;

//A string to use for when we search for an ISBN number
string getISBN;

//Our search results array - pretty much a more selective inventory
Book ** searchResults;
int searchResultsSize; //the size of the array

//All of our display-box for books information
double displayBox[] = {100,100,600,55}; //the size of a display box
bool displayBoxSelected[] = {false,false,false,false,false,false,false,false}; //an array to hold which display box is selected
bool mouseWheel = true; /*THIS IS A MAGIC VARIABLE. There is a weird glitch where when the mouse scrolls, it counts as two 
                          scrolls instead of one. We use this variable to just calculate for every other*/
int displayOffset = 0; //The display offset. Allows us to scrolls through the inventory
int currentScroll = 0; //Another magic variable to help with our scrolling through the inventory

//Our temporary pointers to books
Book * displayedBook = NULL; //Held for whenever we are displaying a books information
Book * removeBook = NULL; //Pointer to any book we want to remove


//Width and height of the program
int WIDTH = 1800;  // width of the user window
int HEIGHT = 800;  // height of the user window

bool fullScreen = false;

/* --------------------- OUR ENUMS ------------------------- */

//Room state - helps us know what to display, along with what to interact with
enum ROOMSTATE {RmSearch, RmAdd, RmRemove};
ROOMSTATE curRoom = RmSearch;

//holds the information on what we are currently searching
enum SEARCHTYPE {SearchAuthor, SearchTitle, SearchISBN};
SEARCHTYPE curSearch = SearchAuthor;
string searchText; //Similar to "getISBN", this will hold the string of what we are searching

//The book condition, for the book condition buttosn when adding a book
enum BOOKCONDITION {New, LikeNew, VeryGood, Good, Acceptable};
BOOKCONDITION bookCondition = New;

//Similar to the book condition buttons, this selects the selling website
enum SELLINGSITE {PleaseSelect, Ebay, Amazon};
SELLINGSITE sellingSite = PleaseSelect;

//And finally, select whether hard or soft cover
enum BOOKCOVER {SoftCover, HardCover};
BOOKCOVER bookCover = HardCover;

/* ------------------------ END OF ENUMS ----------------*/

//Name of the program
char programName[] = "BOOK INVENTORY";
int texAdd, texBack, texX; //Texture variables

/* ---------IMPORTANT FUNCTIONS----------------------*/

//WriteCallBack is used with curl, in order to get the information
static size_t WriteCallback(void *contents, size_t size, size_t nmemb, void *userp)
{
    ((std::string*)userp)->append((char*)contents, size * nmemb);
    return size * nmemb;
}

//Draw a box! :)
void drawBox(double x, double y, double width, double height)
{
  glBegin(GL_POLYGON);
    glVertex2f(x, y);  // upper left
    glVertex2f(x, y + height);  // lower left
    glVertex2f(x + width, y + height);  // lower right
    glVertex2f(x + width, y);  // upper right
  glEnd();
}

//Draw box using pos
void drawBox(double *pos)
{
  drawBox(pos[0], pos[1], pos[2], pos[3]);
}

// close the window and finish the program
void exitAll()
{
  //THIS IS WHAT SAVES THE INFORMATION
  ofstream dbOut("books_db.txt");
  invent.closeGUI(dbOut);
  dbOut.close();

  int win = glutGetWindow(); //gets the window
  glutDestroyWindow(win); //destroys the window
  exit(0); //exits the program
}

// the drawText function draws some text at location x, y
//   note:  the text to be drawn is a C-style string!
void drawText(double x, double y, const char *text)
{
	int length = strlen(text); //Get the string length

  glColor4f(0,0,0,0.25); //Sets color to a low alpha and black, to draw a shadow
  glRasterPos2f( x+1, y+1 ); //Draw a shadow with a little offset
  for (int i = 0; i < length; i++)
    glutBitmapCharacter(GLUT_BITMAP_HELVETICA_12, text[i]);

  glColor3f(0, 0, 0); //Set the color to black
  glRasterPos2f( x, y ); //Draw the text where we want it
  for (int i = 0; i < length; i++)
    glutBitmapCharacter(GLUT_BITMAP_HELVETICA_12, text[i]);
}

void drawTextBig(double x, double y, const char *text)
{
  int length = strlen(text); //String length

  glColor4f(0.3, 0.3, 0.3, 0.3); //The shadow color
  glRasterPos2f( x + 2, y + 2); //Draw shadow with a slight offset
  for (int i = 0; i < length; i++)
    glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, text[i]);


	glColor3f(0, 0, 0); //Set the color back to black
	glRasterPos2f( x-1, y ); //DRAW THE OUTLINE
	for (int i = 0; i < length; i++)
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, text[i]);

  glRasterPos2f( x+1, y ); //OUTLINE
  for (int i = 0; i < length; i++)
    glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, text[i]);

  glRasterPos2f( x, y-1 ); //OUTLINE
  for (int i = 0; i < length; i++)
    glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, text[i]);

  glRasterPos2f( x, y+1 ); //OUTLINE
  for (int i = 0; i < length; i++)
    glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, text[i]);

  glColor3f(1, 0.53, 0.38); //Draw our normal text with the lovely salmon color
  glRasterPos2f( x, y );
  for (int i = 0; i < length; i++)
    glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, text[i]);

}

//On box is similar to on button, however it takes a position array to text the box
bool onBox(int x, int y, double *pos) {
    return x > pos[0]  && y > pos[1] &&
         x < pos[0] + pos[2] &&
         y < pos[1] + pos[3];
}

//DRAWS THE BEAUTIFUL BACKGROUND OF OUR PROGRAM
void drawBackground() {
  //Gradient background
  glMatrixMode (GL_MODELVIEW); 
  glPushMatrix (); 
  glLoadIdentity ();
  glMatrixMode (GL_PROJECTION);
  glPushMatrix (); 
  glLoadIdentity ();

  glBegin (GL_QUADS);
  glColor3f(1,0.73,0.58);
  //glColor3f(1,0.53,0.38);
  glVertex3f (-1.0f, -1.0f, -1.0f); 
  glVertex3f (1.0f, -1.0f, -1.0f); 

  glColor3f(0.45,1,1);
  //glColor3f(0.25,0.88,0.92);
  glVertex3f (1.0f, 1.0f, -1.0f); 
  glVertex3f (-1.0f, 1.0f, -1.0f); 
  glEnd ();

  glPopMatrix (); 
  glMatrixMode (GL_MODELVIEW); 
  glPopMatrix ();

  //Draw the box around most of our information
  glColor4f(0.25, 0.88, 0.92, 0.3);
  drawBox(15, 15, 885, glutGet(GLUT_WINDOW_HEIGHT) - 30);
}

//This is the lovely function that will essentially create a copy of our inventory *without the removed books* to be displayed
void setSearchDefault() {
  delete [] searchResults; //delete any array already there
  searchResultsSize = invent.getNumBooks() - invent.getRemoved(); //get the correct size of the array
  searchResults = new Book * [searchResultsSize]; //Initialize the array
  int i = 0; //Our increment variables
  int ii = 0;

  //This will set our array accordingly
  while(i<searchResultsSize) {
    if(!invent[ii].get_rm()) {
      searchResults[i] = &invent[ii];
      i++;
    }
    ii++;
  }
}

//DISPLAY SEARCH RESULTS ARRAY
void displayResults() {
  for(int i = 0; i < 8; i++) {
    if(i < searchResultsSize) { //IMPORTANT! This will make sure we're not displaying anything we DON'T HAVE!

      //The code below will draw out the box and draw important information
      glColor3f(0.2,0.2,0.2);
      if(searchResults[i+displayOffset]==displayedBook || displayBoxSelected[i]) glColor3f(0.8,0.8,0.2);
      drawBox(displayBox[0]-2, displayBox[1] + (65 * i)-2, displayBox[2]+4, displayBox[3]+4);
      glColor4f(0.45,0.98,1,0.4);
      drawBox(displayBox[0], displayBox[1] + (65 * i), displayBox[2], displayBox[3]);

      //this is to truncate our float so we just display the first two decimal places.
      string s = to_string(i + displayOffset + 1);
      s+=".";
      drawTextBig(105, 130 + (65 * i), s.c_str() );

      //draw the text we need to draw
      drawTextBig(145, 130 + (65 * i), searchResults[i + displayOffset]->get_title().substr(0,23).c_str() );
      drawTextBig(425, 130 + (65 * i), searchResults[i + displayOffset]->get_author().substr(0,20).c_str() );
    }
  }
}
/* ------------- END OF IMPORTANT FUNCTIONS ---------

                HARAMBE
                  ."`".
              .-./ _=_ \.-.
             {  (,(oYo),) }}
             {{ |   "   |} }
             { { \(---)/  }}
             {{  }'-=-'{ } }
             { { }._:_.{  }}
             {{  } -:- { } }
       jgs   {_{ }`===`{  _}          //Gotta give credit to the creator!
            ((((\)     (/)))) 

 ---------------- CLASSES -----------------------*/

//TEXTBOX CLASS YO
class textbox {
public:

	// textbox info
	bool overTextBox = false, TextBoxSelected = false;
	string textInBox = "";
	double textBoxPos[4];  // outer box for text
	unsigned int MAXCHAR;

  //Our constructor
	textbox(int x, int y, int w, int h, int MAX) {
	textBoxPos[0] = x;
	textBoxPos[1] = y;
	textBoxPos[2] = w;
	textBoxPos[3] = h;
	MAXCHAR = MAX;
	}

	void drawTextBox() {
		// draw the textbox
		glColor4f(0, 0, 0, 0.5); 
		drawBox(textBoxPos[0]-2,textBoxPos[1]-2,textBoxPos[2]+4,textBoxPos[3]+4);
    glColor4f(0, 0, 0, 0.5); 
    drawBox(textBoxPos[0]-1,textBoxPos[1]-1,textBoxPos[2]+2,textBoxPos[3]+2);
		if ( TextBoxSelected ) glColor3f(1,0.73,0.58);
		else if ( overTextBox ) glColor3f(1, 0.88, 0.88); 
		else glColor3f(1, 0.73, 0.58);
		drawBox(textBoxPos);
		glColor3f(0, 0, 0); 
		if ( TextBoxSelected ) { 
		string withCursor(textInBox);
		withCursor += '|';
		drawText( textBoxPos[0]+7, textBoxPos[1]+textBoxPos[3]-10, withCursor.c_str() );
		} else drawText( textBoxPos[0]+7, textBoxPos[1]+textBoxPos[3]-10, textInBox.c_str() );
	}

  //Tests to see if were on top of the textbox!
	bool onTextBox(int x, int y){
		return x >= textBoxPos[0] && y >= textBoxPos[1] &&
		    x <= textBoxPos[0]+textBoxPos[2] &&
		    y <= textBoxPos[1]+textBoxPos[3];
	}

  //This allows the user to type - returns true if the user is typing
	bool handleTyping(unsigned char c) {
		if ( TextBoxSelected ) {

		    if ( 27==c ) exitAll();

		    if ( 13==c ) {
		    	return true;
		    } else if ( '\b'==c || 127==c ) {

		    	if ( textInBox.length() > 0 ) textInBox.erase(textInBox.end()-1);

		    } else if ( c >= 32 && c <= 126 ) {

		    	if ( textInBox.length() < MAXCHAR ) textInBox += c;

		    }
		} else {
		    switch(c) {
		    	case 27:
		        exitAll();
		        break;
		    default:
		        break;
		    }
		}

	return false;

	}
};

//BUTTON CLASS
class button {
public:

  //Define the important varianbles
	bool buttonPressed = false, buttonHover = false;
	double buttonPos[4];

  //our constructor
	button(int x, int y, int w, int h) {
		buttonPos[0] = x;
		buttonPos[1] = y;
		buttonPos[2] = w;
		buttonPos[3] = h;
	}

  //This will draw the button, using the rgb values inputted (allows us to change button colors at will)
	void drawButton(double r, double g, double b) {
		glColor3f(0, 0, 0);
		drawBox(buttonPos[0]-2,buttonPos[1]-2,buttonPos[2]+4,buttonPos[3]+4);

    glColor4f(1, 1, 1, 0.5);
    drawBox(buttonPos[0]-1,buttonPos[1]-1,buttonPos[2]+2,buttonPos[3]+2);

		glColor3f(r, g, b);
		drawBox(buttonPos);
	}

  //returns true if the mouse if over the button
	bool onButton(int x, int y) {
	  	return x >= buttonPos[0]  && y >= buttonPos[1] &&
	         x <= buttonPos[0] + buttonPos[2] &&
	         y <= buttonPos[1] + buttonPos[3];
	}

  //makes the repeated code easier to do
	void handleMouse(int x, int y) {
		if ( onButton(x,y) ) buttonPressed = true;
      	else buttonPressed = false;
	}

};
/* --------------------- CLASSES OVER ------------------------- */

/* ------------------- OBJECTS WE NEED --------------------------*/

//Our button to be used for both the add book button along with the back button
button multiUse(40,40,25,25);

//for search screen and ISBN input
textbox searchBar(85,38,650,29,100);

//main screen
button buttAuthor(750,40,25,25);
button buttTitle(800,40,25,25);
button buttISBN(850,40,25,25);

//Add a book - all of the textboxes we need for input information
int numTextBox = 10;
textbox textBoxArr[] = {
	{textbox (385, 85, 350, 29, 50)},
	{textbox (385, 125, 350, 29, 50)},
	{textbox (385, 165, 350, 29, 50)},
	{textbox (385, 205, 350, 29, 50)},
	{textbox (385, 245, 350, 29, 50)},
	{textbox (385, 285, 350, 29, 50)},
	{textbox (385, 325, 350, 29, 50)},
	{textbox (385, 445, 350, 29, 50)},
	{textbox (385, 485, 350, 29, 50)},
	{textbox (385, 525, 350, 29, 50)}
};

//displaying remove boxes
button buttonRemoveArr[] = {
  {button (680, 105, 12, 12)},
  {button (680, 170, 12, 12)},
  {button (680, 235, 12, 12)},
  {button (680, 300, 12, 12)},
  {button (680, 365, 12, 12)},
  {button (680, 430, 12, 12)},
  {button (680, 495, 12, 12)},
  {button (680, 560, 12, 12)}
};

//the buttons for when removing a book
button buttYes(0,0,86,30);
button buttNo(0,0,86,30);
button buttCancel(0,0,86,30);

//Our apply ISBN button
button applyISBN(750,40,85,25);

//our condition buttons
button conNew(385,365,25,25);
button conLikeNew(455,365,25,25);
button conVeryGood(525,365,25,25);
button conGood(595,365,25,25);
button conAcceptable(665,365,25,25);

//Our book cover buttons
button buttHardCover(385,405,105,25);
button buttSoftCover(505,405,105,25);

//Add the book!
button buttAddBook(625,650,105,25);


// slider info - we don't need a class since we only have one
bool sliderIsPressed = false, overSlider = false;
double sliderMax = 600;  // upper limit to the sliderPos
double sliderBox1[] = { 50, 88,   4, sliderMax };  // background of slider
double sliderBox2[] = { 42, 80,   20, 10 };  // foreground of slider
double sliderPos = 0;  // where the slider currently is located
double sliderStartPos;  // where the mouse first clicked on the slider

//DROPDOWN MENU STUFF!
bool dropDownOpen = false, drop1Pressed = false, drop2Pressed = false, drop3Pressed = false; //important variables
bool overDrop1 = false, overDrop2 = false, overDrop3 = false; //more variables.
double dropDown1[] = {385, 565, 245, 29}; //the location 
double dropDown2[] = {385, 594, 245, 29}; //of each of
double dropDown3[] = {385, 623, 245, 29}; //the boxes



/* ---------- SWAG WE GOT THESE ALL DEFINED NOW - LETS DRAW AND STUFF ---------------*/

//draws the window
void drawWindow()
{
  // clear the buffer
  glClear(GL_COLOR_BUFFER_BIT);

  //draws the background
  drawBackground();

  //draw the multiuse button ALWAYS!
  if(multiUse.buttonPressed) multiUse.drawButton(0.9,0.43,0.28);
  else multiUse.drawButton(1,0.53,0.38);

  //Always draw the search bar as well!
  searchBar.drawTextBox();

  //Draw what we need to draw according to what room were in
  switch(curRoom) {
    //switch statement to draw our current room
    case RmSearch : //draw the search room
    case RmRemove : //Also draw the remove room, since it is displayed over the search room
      drawTexture(texAdd,multiUse.buttonPos[0],multiUse.buttonPos[1],multiUse.buttonPos[2],multiUse.buttonPos[3]); //the draw add button texture
      glColor4f(1, 0.53, 0.38, 0.3); //Draw a backbround box! (get the color)
      drawBox(85, 85, 630, 550); //draw the box

      //Draw the current search buttons, with whatever is selected being darker
      if ( curSearch == SearchAuthor ) buttAuthor.drawButton(0.8,0.53,0.38);
      else buttAuthor.drawButton(1,0.73,0.58);

      if ( curSearch == SearchTitle ) buttTitle.drawButton(0.8,0.53,0.38);
      else buttTitle.drawButton(1,0.73,0.58);

      if ( curSearch == SearchISBN ) buttISBN.drawButton(0.8,0.53,0.38);
      else buttISBN.drawButton(1,0.73,0.58);

      // draw the slider background
      if(searchResultsSize>8) {
        glColor3f(0,0,0);
        drawBox(sliderBox1[0]-2,sliderBox1[1]-2,sliderBox1[2]+4,sliderBox1[3]+4);
        if ( sliderIsPressed || overSlider ) glColor3f(0.8,0.53,0.38);
        else glColor3f(1,0.73,0.58);
        drawBox(sliderBox1);
        // draw the slider foreground
        glColor3f(0,0,0);
        drawBox(sliderBox2[0]-2,sliderBox2[1]-2 + sliderPos,sliderBox2[2]+4,sliderBox2[3]+4);
        glColor3f(0.8,0.53,0.38);
        drawBox(sliderBox2[0], sliderBox2[1] + sliderPos, 
                sliderBox2[2],  sliderBox2[3]);
      }

      //Draw text
      glColor3f(0, 0, 0);
      drawText(85, 32, "Search Database:");
      drawText(747, 32, "Search type:");

      //Draw the selected search text
      drawText(757, 55, "A");
      drawText(808, 56, "T");
      drawText(861, 56, "I");

      //the magic function to display all of our search results
      displayResults();

      //Here is drawing all of the remove buttons 
      for(int i = 0; i < 8; i++) {
        if(i < searchResultsSize) {
          if(buttonRemoveArr[i].buttonHover && !buttonRemoveArr[i].buttonPressed) buttonRemoveArr[i].drawButton(0.35,0.35,0.35);
          else buttonRemoveArr[i].drawButton(0.15,0.15,0.15);
          drawTexture(texX,buttonRemoveArr[i].buttonPos[0],
                      buttonRemoveArr[i].buttonPos[1],
                      buttonRemoveArr[i].buttonPos[2],
                      buttonRemoveArr[i].buttonPos[3]);
        }
      }

      //IF WE NEED TO DISPLAY A BOOKS INFORMATION
      if(displayedBook!=NULL) {
        //draw the background box
        glColor4f(1, 0.53, 0.38, 0.3);
        drawBox(925, 85, 1030, 573);

        //temporary string to hold any temp. information
        string s;

        //draw the title
        drawTextBig(945, 135, "Title:");
        drawTextBig(1215, 135, displayedBook->get_title().c_str() );

        //draw the author
        drawTextBig(945, 175, "Author:");
        drawTextBig(1215, 175, displayedBook->get_author().c_str() );

        //draw the ISBN
        drawTextBig(945, 215, "ISBN:");
        drawTextBig(1215, 215, displayedBook->get_isbn().c_str() );

        //Draw the edition, after turning the int into a string
        drawTextBig(945, 255, "Edition:");
        s = to_string(displayedBook->get_edition());
        drawTextBig(1215, 255, s.c_str() );

        //draw the printing
        drawTextBig(945, 295, "Printing:");
        s = to_string(displayedBook->get_printing());
        drawTextBig(1215, 295, s.c_str() );

        //draw the date printed
        drawTextBig(945, 335, "Date Printed:");
        drawTextBig(1215, 335, displayedBook->get_yr_print().c_str() );

        //date purchased
        drawTextBig(945, 375, "Date Purchased:");
        drawTextBig(1215, 375, displayedBook->get_date_purch().c_str() );

        //Switch statement to draw the correct condition
        drawTextBig(945, 415, "Condition:");
        switch (displayedBook->get_condition()) {
          case New:
            drawTextBig(1215, 415, "New" );
            break;
          case LikeNew:
            drawTextBig(1215, 415, "Like New" );
            break;
          case VeryGood:
            drawTextBig(1215, 415, "Very Good" );
            break;
          case Good:
            drawTextBig(1215, 415, "Good" );
            break;
          case Acceptable:
            drawTextBig(1215, 415, "Acceptable" );
          break;
        }

        //Hard/soft cover
        drawTextBig(945, 455, "Hard/Soft Cover:");
        switch(displayedBook->get_cover()) {
          case true:
            drawTextBig(1215, 455, "Hard Cover");
            break;
          case false:
            drawTextBig(1215, 455, "Soft Cover");
            break;
        }

        //Location purchased
        drawTextBig(945, 495, "Location Purchased:");
        drawTextBig(1215, 495, displayedBook->get_loc_purch().c_str() );

        //Paid ammount
        drawTextBig(945, 535, "Paid Amount:");
        s = to_string(displayedBook->get_paid_amt());
        size_t pos = s.find("."); //This is to truncate the float in order to just display two variables
        s = s.substr(0,pos+3);
        drawTextBig(1215, 535, s.c_str() );

        //Selling price
        drawTextBig(945, 575, "Selling Price:");
        s = to_string(displayedBook->get_sell_price());
        pos = s.find(".");
        s = s.substr(0,pos+3);
        drawTextBig(1215, 575, s.c_str() );

        //Selling site
        drawTextBig(945, 615, "Selling Site:");
        switch(displayedBook->get_sell_site()) {
          case Amazon:
            drawTextBig(1215, 615, "Amazon" );
            break;
          case Ebay:
            drawTextBig(1215, 615, "Ebay" );
            break;
        }

      }

      //THIS IS JUST IF WERE REMOVING A BOOK - We have this here so we can get that cool blurred out background look.
      if(curRoom == RmRemove) {
          //Darken out the background and draw the center boxes
          glColor4f(0, 0, 0, 0.7);
          drawBox(0, 0, glutGet(GLUT_WINDOW_WIDTH), glutGet(GLUT_WINDOW_HEIGHT));
          glColor4f(0, 0, 0, 0.7);
          drawBox(glutGet(GLUT_WINDOW_WIDTH)/2 - 102, glutGet(GLUT_WINDOW_HEIGHT)/2 - 152, 204, 254);
          glColor4f(1, 1, 1, 0.7);
          drawBox(glutGet(GLUT_WINDOW_WIDTH)/2 - 100, glutGet(GLUT_WINDOW_HEIGHT)/2 - 150, 200, 250);
          drawTextBig(glutGet(GLUT_WINDOW_WIDTH)/2 - 88, glutGet(GLUT_WINDOW_HEIGHT)/2 - 120, "Did the book sell?" ); //Did the book sell text
          buttYes.buttonPos[0] = glutGet(GLUT_WINDOW_WIDTH)/2 - 43; //Setting our button positions to be in the center of the screen
          buttYes.buttonPos[1] = glutGet(GLUT_WINDOW_HEIGHT)/2 - 90;
          buttNo.buttonPos[0] = glutGet(GLUT_WINDOW_WIDTH)/2 - 43;
          buttNo.buttonPos[1] = glutGet(GLUT_WINDOW_HEIGHT)/2 - 35;
          buttCancel.buttonPos[0] = glutGet(GLUT_WINDOW_WIDTH)/2 - 43;
          buttCancel.buttonPos[1] = glutGet(GLUT_WINDOW_HEIGHT)/2 + 20;

          //Drawing them in the correct color
          if ( buttYes.buttonHover ) buttYes.drawButton(0.8,0.53,0.38);
          else buttYes.drawButton(1,0.73,0.58);
          drawTextBig(glutGet(GLUT_WINDOW_WIDTH)/2 - 23, glutGet(GLUT_WINDOW_HEIGHT)/2 - 68, "Yes");

          if ( buttNo.buttonHover ) buttNo.drawButton(0.8,0.53,0.38);
          else buttNo.drawButton(1,0.73,0.58);
          drawTextBig(glutGet(GLUT_WINDOW_WIDTH)/2 - 18, glutGet(GLUT_WINDOW_HEIGHT)/2 - 13, "No");

          if ( buttCancel.buttonHover ) buttCancel.drawButton(0.8,0.53,0.38);
          else buttCancel.drawButton(1,0.73,0.58);
          drawTextBig(glutGet(GLUT_WINDOW_WIDTH)/2 - 35, glutGet(GLUT_WINDOW_HEIGHT)/2 + 42, "Cancel");

      }

    break;

    //DRAWING THE ADD BOOK ROOM!
    case RmAdd :
      //Drawing background boxes
      glColor4f(1, 0.53, 0.38, 0.3);
      drawBox(375, 75, 370, 539);
      drawBox(35, 75, 225, 539);

      //draw the back button texture
      drawTexture(texBack,multiUse.buttonPos[0],multiUse.buttonPos[1],multiUse.buttonPos[2],multiUse.buttonPos[3]);

      //Draw all of our textboxes
      for(int i = 0; i < numTextBox; i++){
      	textBoxArr[i].drawTextBox();
      }

      //draw the apply ISBN button
      if(applyISBN.buttonPressed) applyISBN.drawButton(0.8,0.53,0.38);
      else applyISBN.drawButton(1,0.73,0.58);

      //Another background box
      glColor4f(1, 0.53, 0.38, 0.3);
      drawBox(618,643,119,39);

      //Handle the addbook button
      if(buttAddBook.buttonPressed) buttAddBook.drawButton(0.8,0.53,0.38);
      else buttAddBook.drawButton(1,0.73,0.58);

      //Draw the addbook text
      drawText(646,666,"Add Book");

      //our condition buttons
      if ( bookCondition == New ) conNew.drawButton(0.8,0.53,0.38);
      else conNew.drawButton(1,0.73,0.58);

      if ( bookCondition == LikeNew ) conLikeNew.drawButton(0.8,0.53,0.38);
      else conLikeNew.drawButton(1,0.73,0.58);

      if ( bookCondition == VeryGood ) conVeryGood.drawButton(0.8,0.53,0.38);
      else conVeryGood.drawButton(1,0.73,0.58);

      if ( bookCondition == Good ) conGood.drawButton(0.8,0.53,0.38);
      else conGood.drawButton(1,0.73,0.58);

      if ( bookCondition == Acceptable ) conAcceptable.drawButton(0.8,0.53,0.38);
      else conAcceptable.drawButton(1,0.73,0.58);

      //Our book cover buttons
      if ( bookCover == SoftCover ) buttSoftCover.drawButton(0.8,0.53,0.38);
      else buttSoftCover.drawButton(1,0.73,0.58);
      drawText(521,420, "Soft Cover");
      if ( bookCover == HardCover ) buttHardCover.drawButton(0.8,0.53,0.38);
      else buttHardCover.drawButton(1,0.73,0.58);
      drawText(400,420, "Hard Cover");

      //HANDLES DRAWING THE DROPDOWN BOX!
      if(dropDownOpen) { //IF IT'S OPEN
        glColor3f(0, 0, 0);
        drawBox(dropDown1[0] - 2, dropDown1[1] - 2, dropDown1[2] + 4, (dropDown1[3]*3) + 4);
        glColor3f(0.5, 0.5, 0.5);
        drawBox(dropDown1[0] - 1, dropDown1[1] - 1, dropDown1[2] + 2, (dropDown1[3]*3) + 2);

        glColor3f(1,0.73,0.58);

        if ( overDrop1 ) glColor3f(0.8,0.53,0.38);
        else glColor3f(1,0.73,0.58);
        drawBox(dropDown1);
        
        if ( overDrop2 ) glColor3f(0.8,0.53,0.38);
        else glColor3f(1,0.73,0.58);
        drawBox(dropDown2);

        if ( overDrop3 ) glColor3f(0.8,0.53,0.38);
        else glColor3f(1,0.73,0.58);
        drawBox(dropDown3);

        drawText(dropDown1[0] + 5,dropDown1[1] + 17, "Please Select");
        drawText(dropDown2[0] + 5,dropDown2[1] + 17, "Amazon");
        drawText(dropDown3[0] + 5,dropDown3[1] + 17, "Ebay");


      } else { //Otherwise draw if it's closed
        glColor3f(0, 0, 0);
        drawBox(dropDown1[0] - 2, dropDown1[1] - 2, dropDown1[2] + 4, dropDown1[3] + 4);
        glColor3f(0.5, 0.5, 0.5);
        drawBox(dropDown1[0] - 1, dropDown1[1] - 1, dropDown1[2] + 2, dropDown1[3] + 2);

        if ( overDrop1 ) glColor3f(0.8,0.53,0.38);
        else glColor3f(1,0.73,0.58);
        drawBox(dropDown1);

        if(sellingSite == PleaseSelect) drawText(dropDown1[0] + 5,dropDown1[1] + 17, "Please Select");
        else if(sellingSite == Amazon) drawText(dropDown1[0] + 5,dropDown1[1] + 17, "Amazon");
        else if(sellingSite == Ebay) drawText(dropDown1[0] + 5,dropDown1[1] + 17, "Ebay");
      }

      drawText(772, 56, "Apply");

      drawText(392, 380, "N");
      drawText(458, 380, "LN");
      drawText(528, 380, "VG");
      drawText(602, 380, "G");
      drawText(672, 380, "A");

      drawText(85, 32, "ISBN (optional):");

      drawTextBig(38, 104, "Title:");
      drawTextBig(38, 144, "Author:");
      drawTextBig(38, 184, "ISBN:");
      drawTextBig(38, 224, "Edition:");
      drawTextBig(38, 264, "Printing:");
      drawTextBig(38, 304, "Date Printed:");
      drawTextBig(38, 344, "Date Purchased:");
      drawTextBig(38, 384, "Condition:");
      drawTextBig(38, 424, "Hard/Soft Cover:");
      drawTextBig(38, 464, "Location Purchased:");
      drawTextBig(38, 504, "Paid Amount:");
      drawTextBig(38, 544, "Selling Price:");
      drawTextBig(38, 584, "Selling Site:");

    break;
  }



  //glColor4f(0, 0, 0, 0.5);
  //drawBox(0, 0, glutGet(GLUT_WINDOW_WIDTH), glutGet(GLUT_WINDOW_HEIGHT));

  glutSwapBuffers();
}


// process keyboard events
void keyboard( unsigned char c, int x, int y )
{
	if(curRoom == RmSearch || curRoom == RmAdd) {
	  searchBar.handleTyping(c);
    if(c==13 && curRoom == RmSearch) {
      if(searchBar.textInBox!="") {
  	  	searchText = searchBar.textInBox;
        switch(curSearch) {

          case SearchTitle:
            delete [] searchResults;
            searchResultsSize = 0;
            invent.sortTitle();
            searchResults = invent.searchTitGUI(searchText);
            while(searchResults[searchResultsSize] != NULL) {
              searchResultsSize++;
            }
            displayOffset = 0;
            sliderPos = 0;
          break;

          case SearchAuthor:
            delete [] searchResults;
            searchResultsSize = 0;
            invent.sortAuthor();
            searchResults = invent.searchAutGUI(searchText);
            while(searchResults[searchResultsSize] != NULL) {
              searchResultsSize++;
            }
            displayOffset = 0;
            sliderPos = 0;
          break;

          case SearchISBN:
            delete [] searchResults;
            searchResultsSize = 0;
            invent.sortISBN();
            searchResults = invent.searchISBNGUI(searchText); //stoul
            while(searchResults[searchResultsSize] != NULL) {
              searchResultsSize++;
            }
            displayOffset = 0;
            sliderPos = 0;
          break;
        }
      } else {setSearchDefault(); displayOffset = 0; sliderPos = 0;}
    } else if(c==13 && curRoom == RmAdd) {

        CURL *curl = curl_easy_init();
        string readBuffer;
        const string Baseurl = "https://www.googleapis.com/books/v1/volumes?q=isbn:";
        getISBN = searchBar.textInBox;
        string myurl = Baseurl + getISBN;
        const char* MyUrl = myurl.c_str();
        if(curl) {
          curl_easy_setopt(curl, CURLOPT_URL, MyUrl);
          curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
          curl_easy_setopt(curl, CURLOPT_WRITEDATA, &readBuffer);
          curl_easy_perform(curl);
          curl_easy_cleanup(curl);
        }
        Document dom;
        dom.Parse(readBuffer.c_str());
        if(dom["totalItems"].GetInt() == 0){
          cout << "No information found" << endl;
        }else{
          textBoxArr[0].textInBox = dom["items"][0]["volumeInfo"]["title"].GetString();
          string author;
          string authors;
          string comma = ", ";
          for(auto &v : dom["items"][0]["volumeInfo"]["authors"].GetArray()){
            author = v.GetString();
            authors += comma + author;
          }
          authors.erase(0,2);
          textBoxArr[1].textInBox = authors;
          textBoxArr[2].textInBox = getISBN;
          textBoxArr[5].textInBox = dom["items"][0]["volumeInfo"]["publishedDate"].GetString();
        }

    }
	}

	if(curRoom == RmAdd) {
		if(c==9) {
			for(int i = 0; i < numTextBox-1; i++) {

				if(textBoxArr[numTextBox-1].TextBoxSelected) {
					textBoxArr[0].TextBoxSelected=true;
					textBoxArr[numTextBox-1].TextBoxSelected=false;
				} else if(textBoxArr[i].TextBoxSelected) {

					textBoxArr[i+1].TextBoxSelected=true;
					textBoxArr[i].TextBoxSelected=false;
					break;

				}
			} 
		}

	  	for(int i = 0; i < numTextBox; i++)
	  		textBoxArr[i].handleTyping(c);
	}

  glutPostRedisplay();
}

// the reshape function handles the case where the user changes the size
//   of the window.  We need to fix the coordinate
//   system, so that the drawing area is still the unit square.
void reshape(int w, int h)
{
   glViewport(0, 0, (GLsizei) w, (GLsizei) h);
   WIDTH = w;  HEIGHT = h;
   glMatrixMode(GL_PROJECTION);
   glLoadIdentity();
   glOrtho(0., WIDTH-1, HEIGHT-1, 0., -1.0, 1.0);
}

// the following function tests whether a point at position x,y is inside
//   the rectangle on the screen corresponding to the slider
bool onSliderForeground(int x, int y)
{
  return x >= sliderBox2[0]  && y >= sliderBox2[1]+sliderPos  &&
         x <= sliderBox2[0]+sliderBox2[2]&&
         y <= sliderBox2[1]+sliderBox2[3]+sliderPos ;
}
bool onSliderBackground(int x, int y)
{
  return x >= sliderBox2[0]  && y >= sliderBox2[1] &&
         x <= sliderBox2[0]+sliderBox2[2] &&
         y <= sliderBox2[1]+sliderBox2[3]+sliderMax;
}

// the mouse function is called when a mouse button is pressed down or released
void mouse(int mouseButton, int state, int x, int y)
{
  if ( GLUT_LEFT_BUTTON == mouseButton ) {

    if ( GLUT_DOWN == state ) {

      switch(curRoom){
        case RmSearch :
          buttAuthor.handleMouse(x,y);
          buttTitle.handleMouse(x,y);
          buttISBN.handleMouse(x,y);

          for(int i = 0; i < 8; i++) {
            if(i < searchResultsSize) {
              buttonRemoveArr[i].handleMouse(x,y);
            }
          }

          if(searchBar.overTextBox==true) {
            searchBar.TextBoxSelected = true;
          } else {
            searchBar.TextBoxSelected = false;
          }

          if(searchResultsSize>8) {
            if ( onSliderForeground(x,y) ) {
              sliderIsPressed = true;
              sliderStartPos = y - sliderPos;
              displayOffset = ( (sliderPos/sliderMax) * (searchResultsSize-8) ) ;
            } else if ( onSliderBackground(x,y) ) {
              sliderIsPressed = true;
              sliderPos = y - sliderBox1[0] - 35;
              sliderStartPos = y-sliderPos;
              displayOffset = ( (sliderPos/sliderMax) * (searchResultsSize-8) ) ;
            } else sliderIsPressed = false;
          }

          break;

        case RmAdd :
          if(searchBar.overTextBox==true) {
            searchBar.TextBoxSelected = true;
          } else {
            searchBar.TextBoxSelected = false;
          }
          applyISBN.handleMouse(x,y);

          buttAddBook.handleMouse(x,y);

          conNew.handleMouse(x,y);
          conLikeNew.handleMouse(x,y);
          conVeryGood.handleMouse(x,y);
          conGood.handleMouse(x,y);
          conAcceptable.handleMouse(x,y);

          buttHardCover.handleMouse(x,y);
          buttSoftCover.handleMouse(x,y);

          for(int i = 0; i < numTextBox; i++){
            if(textBoxArr[i].overTextBox==true) {
              textBoxArr[i].TextBoxSelected = true;
            } else {
              textBoxArr[i].TextBoxSelected = false;
            }
          }

          break;

        case RmRemove :
          buttYes.handleMouse(x,y);
          buttNo.handleMouse(x,y);
          buttCancel.handleMouse(x,y);
          break;
      }

      if(curRoom == RmSearch || curRoom == RmAdd) multiUse.handleMouse(x,y);

    } else {

      // the user just let go the mouse-- do something
      if ( multiUse.onButton(x,y) && multiUse.buttonPressed ) {
        if (curRoom == RmSearch) {curRoom = RmAdd; searchText = searchBar.textInBox; searchBar.textInBox = getISBN;}
        else if (curRoom == RmAdd) {curRoom = RmSearch; getISBN = searchBar.textInBox; searchBar.textInBox = searchText;}
      }
      multiUse.buttonPressed = false;


      switch(curRoom) {

        case RmSearch :
          if ( buttAuthor.onButton(x,y) && buttAuthor.buttonPressed ) {
            curSearch = SearchAuthor;
          }
          buttAuthor.buttonPressed = false;

          if ( buttTitle.onButton(x,y) && buttTitle.buttonPressed ) {
            curSearch = SearchTitle;
          }
          buttTitle.buttonPressed = false;

          if ( buttISBN.onButton(x,y) && buttISBN.buttonPressed ) {
            curSearch = SearchISBN;
          }
          buttISBN.buttonPressed = false;

          sliderIsPressed = false;

          for(int i = 0; i < 8; i++) {
            displayedBook = NULL;
            if(displayBoxSelected[i]) {
              displayedBook = searchResults[i+displayOffset];
              break;
            }
          }

          for(int i = 0; i < 8; i++) {
            if(i < searchResultsSize) {
              if ( buttonRemoveArr[i].onButton(x,y) && buttonRemoveArr[i].buttonPressed ) {
                /* HANDLE REMOVED BOOK */
                removeBook = searchResults[i+displayOffset];
                curRoom = RmRemove;
              }
              buttonRemoveArr[i].buttonPressed = false;
            }
          }

        break;

        case RmAdd :

          if ( buttSoftCover.onButton(x,y) && buttSoftCover.buttonPressed ) {
            bookCover = SoftCover;
          }
          buttSoftCover.buttonPressed = false;

          if ( buttHardCover.onButton(x,y) && buttHardCover.buttonPressed ) {
            bookCover = HardCover;
          }
          buttSoftCover.buttonPressed = false;

          /* -------------------- APPLY ISBN NUMBER -------------------*/

          if ( applyISBN.onButton(x,y) && applyISBN.buttonPressed ) {
            CURL *curl = curl_easy_init();
            string readBuffer;
            const string Baseurl = "https://www.googleapis.com/books/v1/volumes?q=isbn:";
            getISBN = searchBar.textInBox;
            string myurl = Baseurl + getISBN;
            const char* MyUrl = myurl.c_str();
            if(curl) {
              curl_easy_setopt(curl, CURLOPT_URL, MyUrl);
              curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
              curl_easy_setopt(curl, CURLOPT_WRITEDATA, &readBuffer);
              curl_easy_perform(curl);
              curl_easy_cleanup(curl);
            }
            Document dom;
            dom.Parse(readBuffer.c_str());
            if(dom["totalItems"].GetInt() == 0){
              cout << "No information found" << endl;
            }else{
              textBoxArr[0].textInBox = dom["items"][0]["volumeInfo"]["title"].GetString();
              string author;
              string authors;
              string comma = ", ";
              for(auto &v : dom["items"][0]["volumeInfo"]["authors"].GetArray()){
                author = v.GetString();
                authors += comma + author;
              }
              authors.erase(0,2);
              textBoxArr[1].textInBox = authors;
              textBoxArr[2].textInBox = getISBN;
              textBoxArr[5].textInBox = dom["items"][0]["volumeInfo"]["publishedDate"].GetString();
            }

          }
          applyISBN.buttonPressed = false;

          /* -------------------- DONE --------------------------------*/

          if ( buttAddBook.onButton(x,y) && buttAddBook.buttonPressed) {
            //ADD A BOOK TO OUR INVENTORY
            invent.addBookGUI(
              textBoxArr[0].textInBox,
              textBoxArr[1].textInBox,
              textBoxArr[2].textInBox,
              atoi(textBoxArr[3].textInBox.c_str()),
              atoi(textBoxArr[4].textInBox.c_str()),
              textBoxArr[5].textInBox,
              textBoxArr[6].textInBox,
              bookCondition,
              bookCover, //WE'LL CHANGE THIS LATER
              textBoxArr[7].textInBox,
              strtof((textBoxArr[8].textInBox).c_str(),0),
              strtof((textBoxArr[9].textInBox).c_str(),0),
              sellingSite);

            for(int i = 0; i < 10; i++) {
              textBoxArr[i].textInBox = "";
            }
            bookCondition = New;
            sellingSite = PleaseSelect;
            setSearchDefault();
            curRoom = RmSearch;
          }

          buttAddBook.buttonPressed = false;

          if ( conNew.onButton(x,y) && conNew.buttonPressed ) {
            bookCondition = New;
          }
          conNew.buttonPressed = false;

          if ( conLikeNew.onButton(x,y) && conLikeNew.buttonPressed ) {
            bookCondition = LikeNew;
          }
          conLikeNew.buttonPressed = false;

          if ( conVeryGood.onButton(x,y) && conVeryGood.buttonPressed ) {
            bookCondition = VeryGood;
          }
          conVeryGood.buttonPressed = false;

          if ( conGood.onButton(x,y) && conGood.buttonPressed ) {
            bookCondition = Good;
          }
          conGood.buttonPressed = false;

          if ( conAcceptable.onButton(x,y) && conAcceptable.buttonPressed ) {
            bookCondition = Acceptable;
          }
          conAcceptable.buttonPressed = false;

          //DROPDOWN -------------------------- //

          if( onBox(x, y, dropDown1) ) {
            if( dropDownOpen ) {
              dropDownOpen = false;
            } else {
              dropDownOpen = true;
            }
          }
          if( dropDownOpen ) {
            if( onBox(x, y, dropDown2) ) {
              sellingSite = Amazon;
              dropDownOpen = false;
            } else if( onBox(x, y, dropDown3) ) {
              sellingSite = Ebay;
              dropDownOpen = false;
              dropDownOpen = false;
            }
          }
        break;

        case RmRemove :
          if ( buttYes.onButton(x,y) && buttYes.buttonPressed ) {
              //YES STUFF
              invent.rmInventoryGUI();
              removeBook->set_rm(1);

              time_t t = time(NULL);
              tm* timePtr = localtime(&t);
              int yr = 1900 + timePtr->tm_year;
              removeBook->set_year_sold(yr);

              setSearchDefault();

              if(displayOffset>0) displayOffset--;

              curRoom = RmSearch;
          }
          buttYes.buttonPressed = false;

          if ( buttNo.onButton(x,y) && buttNo.buttonPressed ) {
              //NO STUFF
              removeBook->set_rm(1);
              invent.rmInventoryGUI();

              setSearchDefault();

              if(displayOffset>0) displayOffset--;

              curRoom = RmSearch;
          }
          buttNo.buttonPressed = false;

          if ( buttCancel.onButton(x,y) && buttCancel.buttonPressed ) {
              //CANCEL STUFF
              curRoom = RmSearch;
          }
          buttCancel.buttonPressed = false;

          break;
      }
      

    }

  } else if ( GLUT_RIGHT_BUTTON == mouseButton ) {
    searchBar.TextBoxSelected = false;
    for(int i = 0; i < numTextBox; i++){
    	textBoxArr[i].TextBoxSelected = false;
    }
  }

  if(mouseButton==3 && displayOffset>0) {
    if(mouseWheel) {
      displayOffset--;
      sliderPos = (sliderMax/(searchResultsSize-8)) * displayOffset; 
      mouseWheel = false;
    } else {
      mouseWheel=true;
    }

  } else if(mouseButton==4 && displayOffset<searchResultsSize-8) {
    if(mouseWheel) {
      displayOffset++;
      sliderPos = (sliderMax/(searchResultsSize-8)) * displayOffset;
      mouseWheel = false; 
    } else {
      mouseWheel=true;
    }
  }

  glutPostRedisplay();
}

// the mouse_motion function is called when the mouse is being dragged,
//   and gives the current location of the mouse
void mouse_motion(int x,int y)
{
  switch(curRoom) {
    case RmSearch :
      if ( sliderIsPressed ) {
        double newSliderPos = y - sliderStartPos;
        // check that the new slider pos does not go off the end of the slider
        if ( newSliderPos < 0 ) {sliderPos = 0; displayOffset = 0;}
        else if ( newSliderPos > sliderMax ) {sliderPos = sliderMax; displayOffset = searchResultsSize - 8;}
        else {sliderPos = newSliderPos; displayOffset = ( (sliderPos/sliderMax) * (searchResultsSize-8) ) ;}
      } else {

        for(int i = 0; i < 8; i++) {

          if ( buttonRemoveArr[i].onButton(x, y) ) buttonRemoveArr[i].buttonHover = true;
          else buttonRemoveArr[i].buttonHover = false;

          double boxPos[] = {100,100 + ((double) i * 65),600,55};
          if(onBox(x,y,boxPos) && !buttonRemoveArr[i].buttonHover ) {
            displayBoxSelected[i] = true;
          } else {
            displayBoxSelected[i] = false;
          }
        }
        if ( onSliderBackground(x,y) ) overSlider = true;
        else overSlider = false;

      }
      break;
    case RmAdd :
      if ( onBox(x, y, dropDown1) ) overDrop1 = true;
      else overDrop1 = false;
      if ( onBox(x, y, dropDown2) ) overDrop2 = true;
      else overDrop2 = false;
      if ( onBox(x, y, dropDown3) ) overDrop3 = true;
      else overDrop3 = false;

      for(int i = 0; i < numTextBox; i++){
        if ( textBoxArr[i].onTextBox(x,y) ) textBoxArr[i].overTextBox = true;
        else textBoxArr[i].overTextBox = false;
      }
      break;
    case RmRemove :
      if ( buttYes.onButton(x, y) ) buttYes.buttonHover = true;
      else buttYes.buttonHover = false;

      if ( buttNo.onButton(x, y) ) buttNo.buttonHover = true;
      else buttNo.buttonHover = false;

      if ( buttCancel.onButton(x, y) ) buttCancel.buttonHover = true;
      else buttCancel.buttonHover = false;

      break;
  }

  if(curRoom == RmSearch || curRoom == RmAdd) {
    if ( searchBar.onTextBox(x,y) ) searchBar.overTextBox = true;
    else searchBar.overTextBox = false;
  }

  glutPostRedisplay();

}

// the init function sets up the graphics card to draw properly
void init(void)
{
  // clear the window to black
  glClearColor(0.7, 0.7, 0.7, 0.7);
  glClear(GL_COLOR_BUFFER_BIT);

  // set up the coordinate system:  number of pixels along x and y
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  glOrtho(0., WIDTH-1, HEIGHT-1, 0., -1.0, 1.0);

  // allow blending (for transparent textures)
  glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
  glEnable(GL_BLEND);
}


void init_gl_window()
{
  char *argv[] = { programName };
  int argc = sizeof(argv) / sizeof(argv[0]);
  glutInit(&argc, argv);
  glutInitDisplayMode( GLUT_RGBA | GLUT_DOUBLE );
  glutInitWindowSize(WIDTH,HEIGHT);
  glutInitWindowPosition(100,100);
  glutCreateWindow(programName);
  if ( fullScreen ) glutFullScreen();
  
  init();

  texAdd = loadTexture("add2.pam");
  texBack = loadTexture("back.pam");
  texX = loadTexture("x.pam");

  glutDisplayFunc(drawWindow);
  glutReshapeFunc(reshape);
  glutKeyboardFunc(keyboard);
  glutMouseFunc(mouse);
  glutMotionFunc(mouse_motion);
  glutPassiveMotionFunc(mouse_motion);

  glutMainLoop();
}



int main()
{
  int dbSize;
  ifstream db("books_db.txt");
  if(!db){
    dbSize = 0;
    db.close();
  }else{
    db >> dbSize;
  }
  invent.setArraySize(dbSize);
  if(dbSize){
    invent.loadFromDB(db);
  }
  db.close();

  setSearchDefault();

  init_gl_window();
}
