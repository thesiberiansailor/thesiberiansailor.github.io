/** Header file for Book class (using strings in place of char arrays) */

#ifndef _Book2_h_
#define _Book2_h_

#include <iostream>
#include <string>
#include <cstring>
using namespace std;

class Book {
 protected:
  bool rm;  /**< Representing whether the book has been removed from inventory */
  string title;  /**< Title of the book */
  string author;  /**< Author of the book */
  string isbn;  /**< ISBN number of the book */
  int edition;  /**< The edition of the book (first, second, third, etc.); new edition means content has been changed */
  int printing;  /**< What printing the book is; first "batch" of copies printed, or second "batch", or... */
  string yr_print;  /**< The year the book was first published/printed */
  string date_purchase;  /**< The date the bookseller purchased this book */
  int condition;  /**< Condition of the book - New, LikeNew, VeryGood, etc. */
  bool hs_cover;  /**< Indicating whether the book is hardcover or softcover */
  string loc_purch;  /**< The site or store where the book was purchased from */
  float paid_amt;  /**< Amount the bookseller originally paid for the book */
  float sell_price;  /**< Amount the bookseller sold the book for */
  int yr_sold;  /**< Year the book was sold */
  int selling_site; /**< Site the book was sold on (Amazon, EBay, etc.); should only be one word */
 public:
  /** Thirteen-argument constructor
      @param t The title of the book
      @param a The author of the book
      @param I The ISBN number
      @param e The edition number
      @param p The printing number
      @param yP The year the book was printed, as a string
      @param dP The date the book was purchased, as a string
      @param c The condition of the book
      @param hC Whether the book is hard or softcover
      @param lP The location where the book was purchased
      @param pA The amount the bookseller originally paid for the book
      @param sP The amount the bookseller sold the book for
      @param sS The site the book was sold on*/
  Book(string t, string a, string I, int e, int p, string yP, string dP, int c, bool hC, string lP, float pA, float sP, int sS);
  /** Input-stream constructor
      @param is An istream reference, containing input representing the book's info */
  Book(istream &is);
  /** Default constructor; assigns "junk" to the state variables */
  Book();
  /** Copy constructor
      @param bk A reference to another book object */
  Book(Book &bk);


  /** get methods - return the value of the appropriate state variable */
  bool get_rm() { return rm; }
  string get_title() { return title; }
  string get_author() { return author; }
  string get_isbn() { return isbn;}
  int get_edition() { return edition; }
  int get_printing() { return printing; }
  string get_date_purch() { return date_purchase; }
  string get_yr_print() { return yr_print; }
  int get_condition() { return condition; }
  bool get_cover() { return hs_cover; }
  string get_loc_purch() { return loc_purch; }
  float get_paid_amt() { return paid_amt; }
  float get_sell_price() { return sell_price; }
  int get_yr_sold() { return yr_sold; }
  int get_sell_site() { return selling_site; }

  /** State variable assignment methods */
  void set_rm (bool r) { rm = r; }
  void set_title(string t) { title = t; }
  void set_author(string a) { author = a; }
  void set_edition(int ed) { edition = ed; }
  void set_printing(int prin) { printing = prin; }
  void set_date_purch(string datep) { date_purchase = datep; }
  void set_yr_print(string yrp) { yr_print = yrp; }
  void set_condition(int cond) { condition = cond; }
  void set_cover(bool cov) { hs_cover = cov; }
  void set_loc_purch(string locp) { loc_purch = locp; }
  void set_paid_amt(float amt) { paid_amt = amt; }
  void set_sell_price(float price) { sell_price = price; }
  void set_yr_sold(int yrs) { yr_sold = yrs; }
  void set_sell_site(int site) { selling_site = site; }
  void set_year_sold(int yr) {yr_sold = yr;}
  /** Display method - prints title, author, edition, and printing to cout */
  void display();

  /** printAll method - prints ALL of the book's information into an ostream
      @param ostr Ostream reference to hold the book's info for printing */
  void printAll(ostream &ostr);

  /** Assignment operator - state variables of this Book are assigned to copies ofthe corresponding state variables in the argument
      @param bk A reference to the Book object whose information we are copying
      @return This book, after the state variables have been copied */
  Book& operator = (Book &bk);
};


#endif
