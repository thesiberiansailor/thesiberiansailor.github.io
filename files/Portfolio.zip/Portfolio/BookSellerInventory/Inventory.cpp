/** Implementation file for Inventory class */
#include "Inventory.h"
#include<typeinfo>

/** Default constructor */
Inventory::Inventory(){}


/** Single-argument constructor */
Inventory::Inventory(int sz) {
  size = sz; //Size of the array elt
  numBooks = sz; //Number of books in inventory (subject to change differently than size)
  removed = 0;
  elt = new Book* [size];
}

/** Destructor */
Inventory::~Inventory(){
  for(int i = 0; i<size; i++){
    delete elt[i];  // De-allocates the memory for each Book pointer in the array elt
  }
  size = 0;
  delete[] elt;  // De-allocates the memory for the array itself
}

/** Method to adjust the size of elt */
void Inventory::setArraySize(int sz) {
  for(int i = 0; i<size; i++){
    delete elt[i];  // De-allocates the memory for each Book pointer in the array elt
  }
  size = 0;
  delete[] elt;  // De-allocates the memory for the array itself

  size = sz; //Size of the array elt
  numBooks = sz; //Number of books in inventory (subject to change differently than size)
  removed = 0;
  elt = new Book* [size]; // Re-allocates memory for the array elt, based on the new size
}

/** Method to load books from a database */
void Inventory::loadFromDB(istream &istr){
  for(int i = 0; i < size; i++){
    elt[i] = new Book(istr);
  }
}

/** Method to add a book to the inventory (terminal window input) */
void Inventory::addBook(){
  // Before we add a book, we have to check whether there's room in the array elt
  if(numBooks == size){
    int tempSize = size + 15; //15 is the usual number of books listed at one time
    int tempNumBooks = numBooks;
    int tempRemoved = removed;

    // Copy the old contents of the inventory into a buffer array
    Book** temp = new Book* [tempSize];
    for(int i = 0; i < size; i++){
      temp[i] = new Book(*elt[i]);
      delete elt[i];  // De-allocates the memory for each Book pointer in the array elt
    }
    delete[] elt;  // De-allocates the memory for the array itself

    // Copy the inventory contents, state variables from buffer back into elt
    elt = temp;
    size = tempSize;
    numBooks = tempNumBooks;
    removed = tempRemoved;
    for(int n = numBooks; n < size; n++){
      elt[n] = NULL;
    }
  }

  // Inputting the information for the new book
  elt[numBooks] = new Book(std::cin);
  numBooks++;
}


/** Method to add a book to the GUI */
void Inventory::addBookGUI(string t, string a, string I, int e, int p, string yP, string dP, int c, bool hC, string lP, float pA, float sP, int sS){
  if(numBooks == size){
    int tempSize = size + 15; //15 is the usual number of books listed at one time
    int tempNumBooks = numBooks;
    int tempRemoved = removed;
    Book** temp = new Book* [tempSize];
    for(int i = 0; i < size; i++){
      temp[i] = new Book(*elt[i]);
      delete elt[i];
    }
    delete[] elt;
    elt = temp;
    size = tempSize;
    numBooks = tempNumBooks;
    removed = tempRemoved;
    for(int n = numBooks; n < size; n++){
      elt[n] = NULL;
    }
  }
  elt[numBooks] = new Book(t, a, I, e, p, yP, dP, c, hC, lP, pA, sP, sS);
  numBooks++;
}

/** Method to copy over the sold books from another inventory */
void Inventory::copySold(Inventory &invent){

  // Creating a buffer array to hold all books from elt array, sold books from &invent
  int tempSize = size + invent.getRemoved();
  int tempNumBooks = size;
  Book** temp = new Book* [tempSize];
  for(int i = 0; i < numBooks; i++){
    temp[i] = new Book(*elt[i]);  // Copying the books from elt to buffer
    delete elt[i];  // De-allocating Book pointers in elt array
  }
  delete[] elt;  // De-allocating the array itself

  
  // Copying Book pointers for sold books, placing them at the end of the buffer array
  int index = 0;
  for(int i = 0; i < invent.getNumBooks(); i++){
    if(invent.elt[i]->get_yr_sold() != -1){
      temp[tempNumBooks+index] = new Book(*invent.elt[i]);
      temp[tempNumBooks+index]->set_rm(0);
      index++;
    }
  }

  // Copying all books (sold and non-sold) from the buffer array back to elt
  elt = temp;
  size = tempSize;
  numBooks = index + tempNumBooks;
  removed  = 0;
  for(int n = numBooks; n < size; n++){
    elt[n] = NULL;
  }
}

/** Method to remove a book from the inventory */
void Inventory::rmInventory(){
  long bookID;
  display();
  cout << "Enter the ID of the book which you want to remove (Enter -1 to cancel):";
  cin >> bookID;

  // Check to see if user inputted an index within the bounds of elt
  if (bookID == -1 || bookID >= numBooks){
    return;
  }
  elt[bookID]->set_rm(1);  // Set the removed bool for this book to true
  removed++;
  cout << "Is this book sold or not? (y/n): ";
  string str;
  cin >> str;

  // If the book is being sold, use C++ time functions to set current date/year as the year sold
  if (str == "y") {
    time_t t = time(NULL);
    tm* timePtr = localtime(&t);
    int yr = 1900 + timePtr->tm_year;
    elt[bookID]->set_year_sold(yr);
  }
}

/** Method to remove a book from the inventory, in the GUI */
void Inventory::rmInventoryGUI(){
  removed++;
}

/** Method to "close" the inventory - unload the contents into an ostream */
void Inventory::close(ostream &ostr){
  // Print out the number of non-removed books
  numBooks -= removed;
  ostr << numBooks << endl;
  numBooks += removed;

  // Call "printAll" method from Book class for all non-removed books
  for(int i = 0; i < numBooks; i++){
    if(!elt[i]->get_rm()){
      elt[i]->printAll(ostr);
    }
  }
}

/** Method to "close" the inventory - unload the contents into an ostream */
void Inventory::closeGUI(ostream &ostr){
  // Print out the number of non-removed books
  numBooks -= removed;
  ostr << numBooks << endl;
  numBooks += removed;
  ofstream soldDB("soldbook.txt", std::ios_base::app);

  // Call "printAll" method from Book class for all non-removed books
  for(int i = 0; i < numBooks; i++){
    if(!elt[i]->get_rm()){
      elt[i]->printAll(ostr);
    }else{
      if(elt[i]->get_yr_sold()!=-1){
        elt[i]->printAll(soldDB);
      }
    }
  }
  soldDB.close();
}

/** Display method - print non-removed books to standard cout */
void Inventory::display() {
  for( int i = 0; i < numBooks; i++ ) {
    if(!elt[i]->get_rm()){
      cout << i << ". ";
      elt[i]->display();
    }
  }

} 

/** Display method for the sold books */
void Inventory::soldDisplay() {
  for(int i = 0; i < numBooks; i++){
    if(elt[i]->get_yr_sold() != -1){
      cout << i << ". ";
      elt[i]->display();
    }

  }
}

/** Index operator */
Book& Inventory::operator [] (int i) {
  if(i < 0) {
    cout << "Indexes less than 0 or more than " << size << " are invalid." << endl;
    return *elt[0];
  }
  else if(i >= size) {
    cout << "Indexes less than 0 or more than " << size << "are invalid." << endl;
    return *elt[size-1];
  }

  else
    return *elt[i];
}


/** Method to search database by title */
void Inventory::searchTit(string str) {
  cout << "Searching Inventory..." << endl;
  cout << "The following books match your search: " << endl;
  // int j = 1;  // numbers for the list when the search results are displayed
  for (int i = 0; i < numBooks; i++) {
    if(!elt[i]->get_rm()){
      string str2 = elt[i]->get_title();
      if (str2.find(str)!=string::npos) {
	cout << i << ". ";
        elt[i]->display();
	// j++;              // j doesn't appear to actually increment?
      }
    }
  }
  cout << endl;
}

/** Method to search database by title for the GUI */
Book ** Inventory::searchTitGUI(string str) {
  Book ** searchInvent = new Book * [500];
  for(int i = 0; i < 500; i++) {searchInvent[i] = NULL;}
  int count = 0;
  // int j = 1;  // numbers for the list when the search results are displayed
  for (int i = 0; i < numBooks; i++) {
    if(!elt[i]->get_rm()){
      string str2 = elt[i]->get_title();
      if (str2.find(str)!=string::npos) {
        searchInvent[count] = elt[i];
        count++;
      }
    }
  }
  return searchInvent;
}

/** Method to search database by author */
void Inventory::searchAut(string str) {
  cout << "Searching Inventory..." << endl;
  cout << "The following books match your search: " << endl;
  for (int i = 0; i < numBooks; i++) {
    if(!elt[i]->get_rm()){
      string str2 = elt[i]->get_author();
      if (str2.find(str)!=string::npos) {
	// int j = 1;
	cout << i << ". ";
        elt[i]->display();
	// j++;
      }
    }
  }
  cout << endl;
}

/** Method to search database by author for the GUI */
Book ** Inventory::searchAutGUI(string str) {
  Book ** searchInvent = new Book * [500];
  for(int i = 0; i < 500; i++) {searchInvent[i] = NULL;}
  int count = 0;

  for (int i = 0; i < numBooks; i++) {
    if(!elt[i]->get_rm()){
      string str2 = elt[i]->get_author();
      if (str2.find(str)!=string::npos) {
        searchInvent[count] = elt[i];
        count++;
      }
    }
  }

  return searchInvent;

}

/** Method to search database by ISBN */
void Inventory::searchISBN(string is) {
  cout << "Searching Inventory..." << endl;
  cout << "The following book matches your search: " << endl;
  for (int i = 0; i < numBooks; i++) {
    if(!elt[i]->get_rm()){
      string is2 = elt[i]->get_isbn();
      if (is2==is) {
	cout << i << ". ";
        elt[i]->display();
      }
    }
  }
  cout << endl;
}

/** Method to search database by ISBN for the GUI */
Book ** Inventory::searchISBNGUI(string is) {
  Book ** searchInvent = new Book * [500];
  for(int i = 0; i < 500; i++) {searchInvent[i] = NULL;}
  int count = 0;

  for (int i = 0; i < numBooks; i++) {
    if(!elt[i]->get_rm()){
      string is2 = elt[i]->get_isbn();
      if (is2==is) {
        searchInvent[count] = elt[i];
        count++;
      }
    }
  }

  return searchInvent;

}


/** Method to sort database by title */
void Inventory::sortTitle() {
  cout << "Sorting inventory by title..." << endl;
  // Sorting the books in the array elt, using comparison method (see below)
  qsort(elt, numBooks, sizeof(Book*), compTitle);

  // Printing out the new array
  display();
}

/** Helper method to alphabetically compare titles of two books */
int compTitle(const void * a, const void * b) {
  Book* bk1 = (Book*) * ((Book**) a);
  Book* bk2 = (Book*) * ((Book**) b);
  string str1 = bk1->get_title();
  string str2 = bk2->get_title();
  
  return str1.compare(str2);
}


/** Method to sort database by author */
void Inventory::sortAuthor() {
  cout << "Sorting inventory by author..." << endl;
  // Sorting the books in the array elt, using comparison method (see below)
  qsort(elt, numBooks, sizeof(Book*), compAuthor);

  // Printing out the new array
  display();
}

/** Helper method to alphabetically compare authors of two books */
int compAuthor(const void * a, const void * b) {
  Book* bk1 = (Book*) * ((Book**) a);
  Book* bk2 = (Book*) * ((Book**) b);
  string str1 = bk1->get_author();
  string str2 = bk2->get_author();
  
  return str1.compare(str2);
}


/** Method to sort database by paid amount */
void Inventory::sortISBN() {
  cout << "Sorting inventory by ISBN number..." << endl;
  // Sorting the books in the array elt, using comparison method (see below)
  qsort(elt, numBooks, sizeof(Book*), compISBN);

  // Printing out the new array
  display();
}


/** Helper method to compare the paid amounts of two books */
int compISBN(const void * a, const void * b) {
  Book* bk1 = (Book*) * ((Book**) a);
  Book* bk2 = (Book*) * ((Book**) b);
  int isb1 = atoi(bk1->get_isbn().c_str());
  int isb2 = atoi(bk2->get_isbn().c_str());
  
  if ( isb1 < isb2 ) { return 1; }
  else if ( isb1 == isb2 ) { return 0; }
  else { return -1; }
}
