/** Driver file to test Book class **/

#include<iostream>
#include<string>
#include<cstring>
#include "Book2.h"

int main () {
  std::string t1 = "American Goddesses";
  std::string aut1 = "Neil Gaiman";
  Book bk1(t1, aut1, 1, 2001, 2005, true);
  Book bk2;

  std::cout << "After constructors:" << std::endl;
  bk1.display();
  bk2.display();

  std::string t2 = "The Call of Cthulu Part II";
  std::string aut2 = "HP Lovecraft";

  Book bk3(bk2);      // Setting up a copy of bk2 while it's "empty"
  Book bk4;
  bk4 = bk1;

  bk2.set_title(t2);
  bk2.set_author(aut2);
  bk2.set_edition(3);

  std::cout << "After setting info for bk2:" << std::endl;
  bk1.display();
  bk2.display();
  bk3.display();
  bk4.display();
  //...

  return 0;
}
