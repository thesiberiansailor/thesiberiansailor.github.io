#include "menuItem.h"

menuItem::menuItem(int in, string txt){
  index = in;
  text = txt;
}

menuItem::menuItem(){
  index = -1;
  text = '\0';
}

void menuItem::display(){
  cout << index << ".\t" << text << endl;
}
