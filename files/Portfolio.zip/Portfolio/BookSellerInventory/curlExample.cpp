#include <iostream>
#include <string>
#include <curl/curl.h>
#include "json.hpp"
using json = nlohmann::json;

template <typename T, size_t N>
inline
size_t SizeOfArray( const T(&)[ N ] ){
  return N;
}

static size_t WriteCallback(void *contents, size_t size, size_t nmemb, void *userp)
{
    ((std::string*)userp)->append((char*)contents, size * nmemb);
    return size * nmemb;
}


int main(){
  CURL *curl = curl_easy_init();
  std::string readBuffer;
  const std::string Baseurl = "https://www.googleapis.com/books/v1/volumes?q=isbn:";
  std::string isbn;
  std::cout << "Enter a isbn number: ";
  std::cin >> isbn;
  std::string myurl = Baseurl + isbn;
  const char* MyUrl = myurl.c_str();
  if(curl) {
    CURLcode res;
    curl_easy_setopt(curl, CURLOPT_URL, MyUrl);
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &readBuffer);
    res = curl_easy_perform(curl);
    curl_easy_cleanup(curl);
  }
  json jsonBook = json::parse(readBuffer);
  int check = jsonBook.at("totalItems");
  std::string typeCheck = jsonBook["kind"];
  //std::cout << std::setw(4) << jsonBook << "\n\n" << std::endl; //cout all JSON
  if(!check || typeCheck != "books#volumes"){
    std::cout << "No information found" << std::endl;
  }else{
    json bookInfo = jsonBook["items"][0]["volumeInfo"];
    int authSize = (bookInfo["authors"]).size();
    std::string authors = bookInfo["authors"][0];
    for(int i = 1; i < authSize; i++){
      std::string comma = ", ";
      std::string author = bookInfo["authors"][i];
      authors += comma + author;
    }
    std::string title = bookInfo["title"];
    std::string returnedISBN = bookInfo["industryIdentifiers"][0]["identifier"];
    std::string pubDate = bookInfo["publishedDate"];
    std::cout << "author(s): " << authors << std::endl;
    std::cout << "title: " << title << std::endl;
    std::cout << "isbn: " << returnedISBN << std::endl;
    std::cout << "date published: " << pubDate << std::endl;
  }
  return 0;
}
