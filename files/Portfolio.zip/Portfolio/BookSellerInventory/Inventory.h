/** Header file for Inventory class */
/** Represents information about inventory of books, including the number of books in the inventory and so on */
#ifndef _Inventory_h_
#define _Inventory_h_
#include<iostream>
#include<fstream>
#include<string>
#include<cstring>
#include<typeinfo>
#include<ctime>
#include "Book2.h"


// enumerated type for which field we're searching (necessary for GUI)
enum SearchType {title=1, author=2, ISBN=3};


// helper methods for sorting inventory, fully defined in implementation file
int compTitle(const void * bk1, const void * bk2);
int compAuthor(const void * bk1, const void * bk2);
int compISBN(const void * bk1, const void * bk2);

class Inventory {
protected:
  Book** elt; /**< Representing the location of the inventory of books */
  int numBooks;  /**< Indicating the number of books in the inventory */
  int removed; /**< Number of removed books in this inventory */
  int size; /**< Size of the array elt */
public:
  /** Default constructor */
  Inventory();
   /** Single-argument constructor
      @param sz The number of books in the inventory, the size of elt */
  Inventory(int sz);
   /** Destructor */
  ~Inventory();
  /** Gets the number of books actually stored in elt
      @return the number of books for which memory was dynam. allocated */
  int getNumBooks() { return numBooks; };
  /** Gets the number of books that have been removed from the inventory
      @return the number of books removed */
  int getRemoved() { return removed; };
  /** Get the size of elt
      @return size of the array elt */
  int getSize() { return size; };
  /** Load the book's information from database 
      @param istr an istream reference from the database */
  void loadFromDB(istream &istr);
  /** Add a book to the inventory */
  void addBook();
  /** Add a book to the inventory on GUI*/
  void addBookGUI(string t, string a, string I, int e, int p, string yP, string dP, int c, bool hC, string lP, float pA, float sP, int sS);
  /** Copy the sold books from another inventory */
  void copySold(Inventory &invent);
  /** Remove a book from the inventory */
  void rmInventory();
  /** Add +1 to the removed variable */
  void rmInventoryGUI();
  /** Close the database and stream out all the books' information in this inventory 
      @param ostr an ostream reference from the database */
  void close(ostream &ostr);
   /** Close the database on GUI and stream out all the sold books' information in this inventory 
      @param ostr an ostream reference from the GUI books database */
  void closeGUI(ostream &ostr);
   /** Close the sold books database and stream out all the sold books' information in this inventory 
      @param ostr an ostream reference from the sold books database */
  void soldClose(ostream &ostr);
  /** Display all the books' information from the inventory */
  void display();
  /** Display all the books' information from the sold inventory*/
  void soldDisplay();
  /** Index operator 
    @param i Representing the index of the book in the inventory
    @return The information of book with this index */
  Book& operator [] (int i);
  /** Method to search database by title
    @param str the input title's name */
  void searchTit(string str);
  /** Method to search database by author 
    @param str the input author's name */
  void searchAut(string str);
  /** Method to search database by ISBN 
      @param is the input ISBN number */
  void searchISBN(string is);
  /** Method to sort database by title
      @param str the input book title
      @return A pointer to an array of Book-pointers, for all matches found */
  Book ** searchTitGUI(string str);
  /** Method to search database by author 
      @param str the input author's name
      @return A pointer to an array of Book-pointers, for all matches found */
  Book ** searchAutGUI(string str);
  /** Method to search database by ISBN 
      @param is the input ISBN number
      @return A pointer to an array of Book-pointers, for all matches found */
  Book ** searchISBNGUI(string is);
  /** Method to sort database by title */
  void sortTitle();
  /** Method to sort database by author's name */
  void sortAuthor();
  /** Method to sort database by ISBN */
  void sortISBN();
  /** Method to adjust the size of elt */
  void setArraySize(int sz);
};


#endif /* _Inventory_h_ */

