Myles Murphy Portfolio

My personal portfolio. Feature a few projects completed for school.
This includes projects in C++, C, and Java.

ALU Project:
Written in C++, this program is a simulation of a processors ALU

Book Seller Inventory:
Written in C++ with a small team, this program was created to keep inventory for a book store.
My main role was creating "Ver3.cpp", the user-side of the app. This role included heavy communication
with the rest of the team.
If I were to do it again, I would utilize classes much more, and write more comprehensible code.

Chat Bot AI:
Written in Java, this program utilizes a client-server model to provide the client with a simulated
conversation experience. This is done through a number of pre-determined responses in an expanding database.
If I were to do it again, I would make the Admin connection cleaner, and use a more advanced database system.

Hamming Code Project:
Written in C++, this program was created to calculate hamming codes.

Shell Project:
Written in C, this program is a creation of my own shell, with various new features and tweaks.
If I were to do it again, I would make it more reliable and with more functionality.