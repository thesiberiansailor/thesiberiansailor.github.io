//Needed inclusions
#include <iostream>
#include <math.h>
#include <ctime>
#include <cstdlib>
using namespace std;

bool printBin = false; //print our binary values?

long hamming(long val) { //our hamming code function - this function will take in a long, convert it to binary stored as a long array, go through the hamming code algorithm, and finally convert back to a long
  //Needed variables
  long temp; //Temp used to find our binary values
  long data[16]; //Data is used to store our converted hex into binary

  for(int i = 15; i >= 0; i--) { //for loop to traverse our data bits (We know it's 16 bits, hence why i = 15.)
        temp = val % 2; //Find our tempt value, giving us our current binary value
        val /= 2; //Cut our value in half, and truncate it
        data[i] = temp; //Store temp into our binary array -- Please give me an A+
  }
  
  //Store the data values into our hamming code array, into the correct locations
  long ham[21] = {0, 0, data[0], 0, data[1], data[2], data[3], 0, data[4], data[5], data[6], data[7], data[8], data[9], data[10], 0, data[11], data[12], data[13], data[14], data[15]}; 

  //Calculate our parity bits
  ham[0] = (data[0] + data[1] + data[3] + data[4] + data[6] + data[8] + data[10] + data[11] + data[13] + data[15]) % 2; //Calculate parity bit 1
  ham[1] = (data[0] + data[2] + data[3] + data[5] + data[6] + data[9] + data[10] + data[12] + data[13]) % 2; //Parity bit 2
  ham[3] = (data[1] + data[2] + data[3] + data[7] + data[8] + data[9] + data[10] + data[14] + data[15]) % 2; //Pb 4
  ham[7] = (data[4] + data[5] + data[6] + data[7] + data[8] + data[9] + data[10]) % 2; //Pb 8
  ham[15] = (data[11] + data[12] + data[13] + data[14] + data[15]) % 2; //Pb 16

  if(printBin) { //If we want to print binary values as well
    cout << "Converted hex to binary: "; 
    for(int i = 0; i < 15; i++) { //Print the hex binary
      cout << data[i];
    }

    cout << "\nCorresponding hamming code: ";
    for(int i = 0; i < 20; i++) { //print the binary hamming code
      cout << ham[i];
    }
    
    cout << "\n";

  }
  
  //Our return values
  long returnVal = 0;
  for(int i = 0; i < 21; i++) { //Traverse our hamming array
    returnVal += ham[i] * pow(2,20-i); //Convert our binary back into a long
  }

  return returnVal; //return our long

}

int main() { //Our main function

  char in; //char used to store user input
  long input; //A variable to store our input
  srand(time(NULL)); //Set the random seed for random numbers

  cout << "Print binary as well as hex? y/n "; //Prompt the user for their input
  cin >> in; //cin their response
  if(in=='y') { //If we get a yes
    printBin = true; //Set print-binary to true
  }

  cout << endl;

  cin.setf(ios::hex, ios::basefield); //Set our base i/o settings to run in hex
  cout.setf(ios::hex, ios::basefield);

  do {
    cout << "Input hex value? (Otherwise, generate random hex value) y/n "; //Prompt the user if they want to input a value, or go off of a randomly generated value
    cin >> in; //Cin their response

    if(in == 'y') { //if they say yes
      cout << "Enter a four-digit hexadecimal value: "; //Prompt the user
      cin >> input; //Get user input
    } else {
      input = rand() % 65536; //random range from 0 to the max number a 16 bit value can be
      cout << "\nRandom hex value is " << input << endl;
    }

  cout << "The hamming code is " << hamming(input) << "\n"; //Print the proper hammingcode hex value

  cout << "Process another value? y/n ";
  cin >> in; //Cin their response
  cout << endl;
  } while(in == 'y'); //continue if they say yes

  return 0; //return main
}
